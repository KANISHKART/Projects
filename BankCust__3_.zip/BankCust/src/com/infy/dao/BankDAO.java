package com.infy.dao;

import java.util.Dictionary;
import java.util.List;

import com.infy.model.BankDetail;



public interface BankDAO {
	
	
	
	public BankDetail addetails(BankDetail bank);
	
	public Integer balance(String accountNumber, String bankName,String Pin);

	public List transfer(BankDetail bank);
	
	public String transferMoney(BankDetail bank,List l,List list,String pin);

	public Dictionary compare(BankDetail bank,int amount, int year);
}
