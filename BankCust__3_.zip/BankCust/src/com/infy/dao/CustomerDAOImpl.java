package com.infy.dao;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.request.RequestContextHolder;

import com.infy.entity.CustomerDetailEntity;
import com.infy.model.CustomerDetail;
import com.infy.service.CustomerService;
import com.infy.service.CustomerServiceImpl;
import com.infy.entity.sessionEntity;
import com.infy.model.sessiontrack;

@Repository("custdao")
public class CustomerDAOImpl implements CustomerDAO  {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public CustomerDetail getdetails(Integer customerid) {
		System.out.println("in customer");
		Session session = sessionFactory.getCurrentSession();
		CustomerDetailEntity bankdetailEntity = session.get(CustomerDetailEntity.class,customerid);
		
		if(bankdetailEntity !=null) {
			
			CustomerDetail obj = new CustomerDetail();
			obj.setCustomerid(bankdetailEntity.getCustomerid());
			obj.setDob(bankdetailEntity.getDob());
			obj.setEmailid(bankdetailEntity.getEmailid());
			obj.setFirstname(bankdetailEntity.getFirstname());
			obj.setLastname(bankdetailEntity.getLastname());
			obj.setMiddlename(bankdetailEntity.getMiddlename());
			obj.setPhoneno(bankdetailEntity.getPhoneno());
			obj.setPassword(bankdetailEntity.getPassword());
			obj.setRepassword(bankdetailEntity.getRepassword());
			
			return obj;
		}
		
		return null;
		
	}
	

	@Override
	public CustomerDetail updatePhoneNumber(CustomerDetail bank) {
		Session session = sessionFactory.getCurrentSession();
		CustomerDetailEntity bankDetailEntity = session.get(CustomerDetailEntity.class, bank.getCustomerid());
		for(int i=10000;i<bank.getCustomerid();i++){
			CustomerDetailEntity bde = session.get(CustomerDetailEntity.class,i);
			System.out.println("inside for");
			if(bde.getPhoneno().equals(bank.getPhoneno())) {
					return null;}
			}
		if(	bankDetailEntity !=null) {
			bankDetailEntity.setPhoneno(bank.getPhoneno());
			return bank;
		}
		return null;
	}
	
	@Override
	public CustomerDetail add(CustomerDetail cust) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
	
		CustomerDetailEntity cde=session.get(CustomerDetailEntity.class,cust.getCustomerid());
		String phoneNumber=cust.getPhoneno();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<CustomerDetailEntity> cq=builder.createQuery(CustomerDetailEntity.class);
		Root<CustomerDetailEntity> root=cq.from(CustomerDetailEntity.class);
		cq.select(root);
		cq.where(builder.like(root.get("phoneno"),phoneNumber));
		List<CustomerDetailEntity> customerEntityList = session.createQuery(cq).list();
		
		if(!(customerEntityList.isEmpty())){
			return null;
		}
		
		if(cde!=null ){return null;}
		 
		else{
			CustomerDetailEntity cd=new CustomerDetailEntity();
			cd.setCustomerid(cust.getCustomerid());
			cd.setDob(cust.getDob());
			cd.setEmailid(cust.getEmailid());
			cd.setFirstname(cust.getFirstname());
			cd.setLastname(cust.getLastname());
			cd.setMiddlename(cust.getMiddlename());
			cd.setPhoneno(cust.getPhoneno());
			cd.setPassword(cust.getPassword());
			cd.setRepassword(cust.getRepassword());
			session.save(cd);
			return cust;
		}
		
	}

		
	@Override
	public sessiontrack session(sessiontrack ses) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.getCurrentSession();
		System.out.println("--------------");
		System.out.println(ses.getSessionid());
		System.out.println(ses.getCustomerid());
		System.out.println("--------------");
		ses.setSessionid(RequestContextHolder.currentRequestAttributes().getSessionId());

		sessionEntity s=new sessionEntity();
		sessionEntity se=session.get(sessionEntity.class,RequestContextHolder.currentRequestAttributes().getSessionId());
		s.setSessionid(ses.getSessionid());
		s.setCustomerid(ses.getCustomerid());
		System.out.println(s.getSessionid());
		session.save(s);
		return ses;
		
		
	}
	
	@Override
	public CustomerDetail login(String phoneno, String password) {
		// TODO Auto-generated method stub
		
		Session lsession=sessionFactory.getCurrentSession();
		
		String phoneNumber=phoneno;
		String pass=password;
		CriteriaBuilder builder=lsession.getCriteriaBuilder();
		CriteriaQuery<CustomerDetailEntity> cq=builder.createQuery(CustomerDetailEntity.class);
		Root<CustomerDetailEntity> root=cq.from(CustomerDetailEntity.class);
		cq.select(root);
		cq.where(builder.and(
				builder.like(root.get("phoneno"),phoneNumber),
				builder.like(root.get("password"),pass)));
		List<CustomerDetailEntity> customerEntityList = lsession.createQuery(cq).list();
		
		CustomerDetailEntity bankdetailEntity =lsession.get(CustomerDetailEntity.class,customerEntityList.get(0).getCustomerid());
	
		
		if(bankdetailEntity !=null) {
			
			CustomerDetail obj = new CustomerDetail();
			obj.setCustomerid(bankdetailEntity.getCustomerid());
			obj.setDob(bankdetailEntity.getDob());
			obj.setEmailid(bankdetailEntity.getEmailid());
			obj.setFirstname(bankdetailEntity.getFirstname());
			obj.setLastname(bankdetailEntity.getLastname());
			obj.setMiddlename(bankdetailEntity.getMiddlename());
			obj.setPhoneno(bankdetailEntity.getPhoneno());
			obj.setPassword(bankdetailEntity.getPassword());
			obj.setRepassword(bankdetailEntity.getRepassword());
		
			return obj;
		}
		return null;
		}


	@Override
	public String logout() {
		// TODO Auto-generated method stub
		System.out.println("in service");
		Session session=sessionFactory.getCurrentSession();
		session.close();
		return "logged out";
		
	}
}
