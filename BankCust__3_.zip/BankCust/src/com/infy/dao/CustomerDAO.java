package com.infy.dao;

import com.infy.model.CustomerDetail;
import com.infy.model.sessiontrack;

public interface CustomerDAO {
	
	public CustomerDetail getdetails(Integer customerid);

	public CustomerDetail updatePhoneNumber(CustomerDetail bank);
	
	public CustomerDetail add(CustomerDetail cust);
	
	public CustomerDetail login(String phoneno,String password);
	
	public sessiontrack session(sessiontrack ses);
	
	public String logout() ;


}
