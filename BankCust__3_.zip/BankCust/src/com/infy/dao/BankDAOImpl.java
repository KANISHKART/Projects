package com.infy.dao;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;


import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.request.RequestContextHolder;

import com.infy.entity.AXISEntity;
import com.infy.entity.BOIEntity;
import com.infy.entity.BankDetailEntity;
import com.infy.entity.CustomerDetailEntity;
import com.infy.entity.HDFCEntity;
import com.infy.entity.ICICIEntity;
import com.infy.entity.InterestEntity;
import com.infy.entity.KVBEntity;
import com.infy.entity.SBIEntity;
import com.infy.model.AXIS;
import com.infy.model.BankDetail;
import com.infy.model.CustomerDetail;
import com.infy.service.BankService;



@Repository("dao")
public class BankDAOImpl implements BankDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public Dictionary compare(BankDetail bank,int amount, int year) {
		// TODO Auto-generated method stub
		System.out.println("In service");
		Dictionary fin=new Hashtable<>();
		Session session=sessionFactory.getCurrentSession();
		String custid=bank.getCustomer().getCustomerid().toString();
		String bankname = "";

		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<BankDetailEntity> cq=builder.createQuery(BankDetailEntity.class);
		Root<BankDetailEntity> root=cq.from(BankDetailEntity.class);
		cq.select(root);
		cq.equals(bank);
		List<BankDetailEntity> bankl= session.createQuery(cq).list();
		
		CriteriaBuilder build=session.getCriteriaBuilder();
		CriteriaQuery<InterestEntity> c=build.createQuery(InterestEntity.class);
		Root<InterestEntity> r=c.from(InterestEntity.class);
		c.select(r);
	
		List<InterestEntity> interest= session.createQuery(c).list();
		if(interest.contains(bankl)){
			System.out.println("in if condition");
		}
		for(int i=0;i<bankl.size();i++){
			for(int j=0;j<interest.size();j++){
				if(bankl.get(i).getBankName().equals(interest.get(j).getBankName())){
					System.out.println(bankl.get(i).getBankName());
					double total=((int) (amount*(interest.get(j).getInterest()))*year)/100;
					fin.put(bankl.get(i).getBankName(),total);
				}
			}
		}
		System.out.println(fin.get("SBI"));
		return fin;
	}




	@Override
	public List transfer(BankDetail bank) {
		
		Session session=sessionFactory.getCurrentSession();
		
		String custid=bank.getCustomer().getCustomerid().toString();
		String bankname = "";
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<BankDetailEntity> cq=builder.createQuery(BankDetailEntity.class);
		Root<BankDetailEntity> root=cq.from(BankDetailEntity.class);
		cq.select(root);
		cq.equals(bank);
		List<BankDetailEntity> bankl= session.createQuery(cq).list();
	
		List<String> banklist=new ArrayList<String>();
		for(int i=0;i<bankl.size();i++){
			banklist.add(bankl.get(i).getBankName());
		}
		System.out.println(banklist);
		
		CriteriaBuilder builder1=session.getCriteriaBuilder();
		CriteriaQuery<InterestEntity> cq1=builder1.createQuery(InterestEntity.class);
		Root<InterestEntity> root1=cq1.from(InterestEntity.class);
		cq1.select(root1);
		cq1.orderBy(builder1.desc(root1.get("interest")));
		List<InterestEntity> Inter= session.createQuery(cq1).list();
		
		List f=new ArrayList<>();
		for(int i=0;i<Inter.size();i++){
			if(banklist.contains(Inter.get(i).getBankName())){
				f.add(Inter.get(i).getBankName());
				
			}
		}
		System.out.println(f);

		return f;
	
	}
	
	
	@Override
	public String transferMoney(BankDetail bank,List l,List list,String pin) {
		// TODO Auto-generated method stub
	Session session=sessionFactory.getCurrentSession();
	
	String custid=bank.getCustomer().getCustomerid().toString();
	String bankname = "";

	CriteriaBuilder builder=session.getCriteriaBuilder();
	CriteriaQuery<BankDetailEntity> cq=builder.createQuery(BankDetailEntity.class);
	Root<BankDetailEntity> root=cq.from(BankDetailEntity.class);
	cq.select(root);
	cq.equals(bank);
	List<BankDetailEntity> bankl= session.createQuery(cq).list();
		System.out.println(bankl.get(0).getBankName());
		List<BankDetailEntity> last=new ArrayList<>();
	for(int k=0;k<l.size();k++){
		for(int p=0;p<bankl.size();p++){
			if(bankl.get(p).getBankName().contains(l.get(k).toString())){
				last.add(bankl.get(p));
			}
		}
	}
	System.out.println("phew"+last.get(0).getBankName());
	int totalamnt=0,deduct=0;
	for(int i=0;i<list.size();i++){	
	totalamnt+=(int) list.get(i);
	}

	
	CriteriaBuilder build=session.getCriteriaBuilder();
	CriteriaQuery<BankDetailEntity> bde=build.createQuery(BankDetailEntity.class);
	Root<BankDetailEntity> r1=bde.from(BankDetailEntity.class);
	bde.select(r1);
	bde.where(build.like(r1.get("accountNumber"),last.get(0).getAccountNumber()));
	List<BankDetailEntity> plist= session.createQuery(bde).list();
	System.out.println("WHOOOOOO"+plist.get(0).getPin()+pin);
	
	if(!(plist.get(0).getPin().toString().equals(pin))){
		System.out.println("in if");
		return "pin_error";
	}
		
	
	
for(int j=0;j<l.size();j++){	
	
	
	
	
		if(last.get(j).getBankName().equals("SBI")){
		
		if (j==0){
		SBIEntity cde=session.get(SBIEntity.class,last.get(j).getAccountNumber());
		totalamnt+=cde.getBalance();
		String account=last.get(j).getAccountNumber();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<SBIEntity> cu=cb.createCriteriaUpdate(SBIEntity.class);
		Root<SBIEntity> r=cu.from(SBIEntity.class);
		cu.set(r.get("balance"),totalamnt);
		cu.where(cb.equal(r.get("accountNumber"),account));
		Query query =session.createQuery(cu);
        Integer result = query.executeUpdate();
		}
		else{
			
			SBIEntity cde=session.get(SBIEntity.class,last.get(j).getAccountNumber());
			Integer temp=(Integer) list.get(j-1);
			deduct=cde.getBalance()-temp;
			String account=last.get(j).getAccountNumber();
			CriteriaBuilder cb=session.getCriteriaBuilder();
			CriteriaUpdate<SBIEntity> cu=cb.createCriteriaUpdate(SBIEntity.class);
			Root<SBIEntity> r=cu.from(SBIEntity.class);
			cu.set(r.get("balance"),deduct);
			cu.where(cb.equal(r.get("accountNumber"),account));
			Query query =session.createQuery(cu);
	        Integer result = query.executeUpdate();
			
			
			}
		}
		
		else if(last.get(j).getBankName().equals("AXIS")){
			if(j==0){
			AXISEntity cde=session.get(AXISEntity.class,last.get(j).getAccountNumber());
			totalamnt+=cde.getBalance();
			String account=last.get(j).getAccountNumber();
			CriteriaBuilder cb=session.getCriteriaBuilder();
			CriteriaUpdate<AXISEntity> cu=cb.createCriteriaUpdate(AXISEntity.class);
			Root<AXISEntity> r=cu.from(AXISEntity.class);
			cu.set(r.get("balance"),totalamnt);
			cu.where(cb.equal(r.get("accountNumber"),account));
			Query query =session.createQuery(cu);
	        Integer result = query.executeUpdate();
			}
			else{
				AXISEntity cde=session.get(AXISEntity.class,last.get(j).getAccountNumber());
				Integer temp=(Integer) list.get(j-1);
				deduct=cde.getBalance()-temp;
				String account=last.get(j).getAccountNumber();
				CriteriaBuilder cb=session.getCriteriaBuilder();
				CriteriaUpdate<AXISEntity> cu=cb.createCriteriaUpdate(AXISEntity.class);
				Root<AXISEntity> r=cu.from(AXISEntity.class);
				cu.set(r.get("balance"),deduct);
				cu.where(cb.equal(r.get("accountNumber"),account));
				Query query =session.createQuery(cu);
		        Integer result = query.executeUpdate();
			}
		}
		
else if(last.get(j).getBankName().equals("HDFC")){
	if(j==0){
	HDFCEntity cde=session.get(HDFCEntity.class,last.get(j).getAccountNumber());
	totalamnt+=cde.getBalance();
	String account=last.get(j).getAccountNumber();
	CriteriaBuilder cb=session.getCriteriaBuilder();
	CriteriaUpdate<HDFCEntity> cu=cb.createCriteriaUpdate(HDFCEntity.class);
	Root<HDFCEntity> r=cu.from(HDFCEntity.class);
	cu.set(r.get("balance"),totalamnt);
	cu.where(cb.equal(r.get("accountNumber"),account));
	Query query =session.createQuery(cu);
    Integer result = query.executeUpdate();
	}
	else{
		HDFCEntity cde=session.get(HDFCEntity.class,last.get(j).getAccountNumber());
		Integer temp=(Integer) list.get(j-1);
		deduct=cde.getBalance()-temp;
		String account=last.get(j).getAccountNumber();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<HDFCEntity> cu=cb.createCriteriaUpdate(HDFCEntity.class);
		Root<HDFCEntity> r=cu.from(HDFCEntity.class);
		cu.set(r.get("balance"),deduct);
		cu.where(cb.equal(r.get("accountNumber"),account));
		Query query =session.createQuery(cu);
	    Integer result = query.executeUpdate();
	}
	
		}
		
else if(last.get(j).getBankName().equals("KVB")){
	if(j==0){
	KVBEntity cde=session.get(KVBEntity.class,last.get(j).getAccountNumber());
	totalamnt+=cde.getBalance();
	String account=last.get(j).getAccountNumber();
	CriteriaBuilder cb=session.getCriteriaBuilder();
	CriteriaUpdate<KVBEntity> cu=cb.createCriteriaUpdate(KVBEntity.class);
	Root<KVBEntity> r=cu.from(KVBEntity.class);
	cu.set(r.get("balance"),totalamnt);
	cu.where(cb.equal(r.get("accountNumber"),account));
	Query query =session.createQuery(cu);
    Integer result = query.executeUpdate();
	}
	else{
		KVBEntity cde=session.get(KVBEntity.class,last.get(j).getAccountNumber());
		Integer temp=(Integer) list.get(j-1);
		deduct=cde.getBalance()-temp;
		String account=last.get(j).getAccountNumber();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<KVBEntity> cu=cb.createCriteriaUpdate(KVBEntity.class);
		Root<KVBEntity> r=cu.from(KVBEntity.class);
		cu.set(r.get("balance"),deduct);
		cu.where(cb.equal(r.get("accountNumber"),account));
		Query query =session.createQuery(cu);
	    Integer result = query.executeUpdate();
	}
}
		
		
else if(last.get(j).getBankName().equals("BOI")){
	if(j==0){
	BOIEntity cde=session.get(BOIEntity.class,last.get(j).getAccountNumber());
	totalamnt+=cde.getBalance();
	String account=last.get(j).getAccountNumber();
	CriteriaBuilder cb=session.getCriteriaBuilder();
	CriteriaUpdate<BOIEntity> cu=cb.createCriteriaUpdate(BOIEntity.class);
	Root<BOIEntity> r=cu.from(BOIEntity.class);
	cu.set(r.get("balance"),totalamnt);
	cu.where(cb.equal(r.get("accountNumber"),account));
	Query query =session.createQuery(cu);
    Integer result = query.executeUpdate();
	}
	else{
		BOIEntity cde=session.get(BOIEntity.class,last.get(j).getAccountNumber());
		Integer temp=(Integer) list.get(j-1);
		deduct=cde.getBalance()-temp;
		String account=last.get(j).getAccountNumber();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<BOIEntity> cu=cb.createCriteriaUpdate(BOIEntity.class);
		Root<BOIEntity> r=cu.from(BOIEntity.class);
		cu.set(r.get("balance"),deduct);
		cu.where(cb.equal(r.get("accountNumber"),account));
		Query query =session.createQuery(cu);
	    Integer result = query.executeUpdate();
		
	}
}
else if(last.get(j).getBankName().equals("ICICI")){
	if(j==0){
	ICICIEntity cde=session.get(ICICIEntity.class,last.get(j).getAccountNumber());
	totalamnt+=cde.getBalance();
	String account=last.get(j).getAccountNumber();
	CriteriaBuilder cb=session.getCriteriaBuilder();
	CriteriaUpdate<ICICIEntity> cu=cb.createCriteriaUpdate(ICICIEntity.class);
	Root<ICICIEntity> r=cu.from(ICICIEntity.class);
	cu.set(r.get("balance"),totalamnt);
	cu.where(cb.equal(r.get("accountNumber"),account));
	Query query =session.createQuery(cu);
    Integer result = query.executeUpdate();
	}
	else{
		ICICIEntity cde=session.get(ICICIEntity.class,last.get(j).getAccountNumber());
		Integer temp=(Integer) list.get(j-1);
		deduct=cde.getBalance()-temp;
		String account=last.get(j).getAccountNumber();
		CriteriaBuilder cb=session.getCriteriaBuilder();
		CriteriaUpdate<ICICIEntity> cu=cb.createCriteriaUpdate(ICICIEntity.class);
		Root<ICICIEntity> r=cu.from(ICICIEntity.class);
		cu.set(r.get("balance"),deduct);
		cu.where(cb.equal(r.get("accountNumber"),account));
		Query query =session.createQuery(cu);
	    Integer result = query.executeUpdate();
	}
}
	
}
		return "success";
		
	}
	
	
	@Override
	public BankDetail addetails(BankDetail bank) {
		// TODO Auto-generated method stub

		Session session=sessionFactory.getCurrentSession();
		
		if(bank.getBankName().equals("SBI")){
			
		SBIEntity cde=session.get(SBIEntity.class,bank.getAccountNumber());
		String accountno=bank.getAccountNumber();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<SBIEntity> cq=builder.createQuery(SBIEntity.class);
		Root<SBIEntity> root=cq.from(SBIEntity.class);
		cq.select(root);
		cq.where(builder.and(
				builder.like(root.get("accountNumber"),accountno),
				builder.like(root.get("name"),bank.getName()),
				builder.like(root.get("ifsc"),bank.getIfsc())));
		List<SBIEntity> SBI= session.createQuery(cq).list();
		
		if(SBI.isEmpty()){
			return null;
		}
		}
		if(bank.getBankName().equals("BOI")){
			
			BOIEntity cde=session.get(BOIEntity.class,bank.getAccountNumber());
			String accountno=bank.getAccountNumber();
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<BOIEntity> cq=builder.createQuery(BOIEntity.class);
			Root<BOIEntity> root=cq.from(BOIEntity.class);
			cq.select(root);
			cq.where(builder.and(
					builder.like(root.get("accountNumber"),accountno),
					builder.like(root.get("name"),bank.getName()),
					builder.like(root.get("ifsc"),bank.getIfsc())));
			List<BOIEntity> SBI= session.createQuery(cq).list();
			
			if(SBI.isEmpty()){
				return null;
			}
			}
			if(bank.getBankName().equals("ICICI")){
			System.out.println("IN ICICI");
			ICICIEntity cde=session.get(ICICIEntity.class,bank.getAccountNumber());
			String accountno=bank.getAccountNumber();
			String phoneno=bank.getPhoneNumber();
			CriteriaBuilder builder=session.getCriteriaBuilder();
			CriteriaQuery<ICICIEntity> cq=builder.createQuery(ICICIEntity.class);
			Root<ICICIEntity> root=cq.from(ICICIEntity.class);
			cq.select(root);
			cq.where(builder.and(
					builder.like(root.get("accountNumber"),accountno),
					builder.like(root.get("name"),bank.getName()),
					builder.like(root.get("ifsc"),bank.getIfsc())));
			List<ICICIEntity> SBI= session.createQuery(cq).list();
			
			if(SBI.isEmpty()){
				return null;
			}
			}
			
			if(bank.getBankName().equals("KVB")){
				
				KVBEntity cde=session.get(KVBEntity.class,bank.getAccountNumber());
				String accountno=bank.getAccountNumber();
				CriteriaBuilder builder=session.getCriteriaBuilder();
				CriteriaQuery<KVBEntity> cq=builder.createQuery(KVBEntity.class);
				Root<KVBEntity> root=cq.from(KVBEntity.class);
				cq.select(root);
				cq.where(builder.and(
						builder.like(root.get("accountNumber"),accountno),
						builder.like(root.get("name"),bank.getName()),
						builder.like(root.get("ifsc"),bank.getIfsc())));
				List<KVBEntity> SBI= session.createQuery(cq).list();
				
				if(SBI.isEmpty()){
					return null;
				}
				}

			if(bank.getBankName().equals("AXIS")){
				
				AXISEntity cde=session.get(AXISEntity.class,bank.getAccountNumber());
				String accountno=bank.getAccountNumber();
				CriteriaBuilder builder=session.getCriteriaBuilder();
				CriteriaQuery<AXISEntity> cq=builder.createQuery(AXISEntity.class);
				Root<AXISEntity> root=cq.from(AXISEntity.class);
				cq.select(root);
				cq.where(builder.and(
						builder.like(root.get("accountNumber"),accountno),
						builder.like(root.get("name"),bank.getName()),
						builder.like(root.get("ifsc"),bank.getIfsc())));
				List<AXISEntity> SBI= session.createQuery(cq).list();
				
				if(SBI.isEmpty()){
					return null;
				}
				}

			if(bank.getBankName().equals("HDFC")){
				
				HDFCEntity cde=session.get(HDFCEntity.class,bank.getAccountNumber());
				String accountno=bank.getAccountNumber();
				CriteriaBuilder builder=session.getCriteriaBuilder();
				CriteriaQuery<HDFCEntity> cq=builder.createQuery(HDFCEntity.class);
				Root<HDFCEntity> root=cq.from(HDFCEntity.class);
				cq.select(root);
				cq.where(builder.and(
						builder.like(root.get("accountNumber"),accountno),
						builder.like(root.get("name"),bank.getName()),
						builder.like(root.get("ifsc"),bank.getIfsc())));
				List<HDFCEntity> SBI= session.createQuery(cq).list();
				
				if(SBI.isEmpty()){
					return null;
				}
				}
			CustomerDetailEntity cd=new CustomerDetailEntity();
			cd.setCustomerid(bank.getCustomer().getCustomerid());
			cd.setDob(bank.getCustomer().getDob());
			cd.setEmailid(bank.getCustomer().getEmailid());
			cd.setFirstname(bank.getCustomer().getFirstname());
			cd.setLastname(bank.getCustomer().getLastname());
			cd.setMiddlename(bank.getCustomer().getMiddlename());
			cd.setPassword(bank.getCustomer().getPassword());
			cd.setRepassword(bank.getCustomer().getRepassword());
			cd.setPhoneno(bank.getCustomer().getPhoneno());
			
			
			BankDetailEntity bde=new BankDetailEntity();
			
			bde.setAccountNumber(bank.getAccountNumber());
			bde.setIfsc(bank.getIfsc());
			bde.setName(bank.getName());
			bde.setPhoneNumber(bank.getPhoneNumber());
			bde.setPin(bank.getPin());
			bde.setBankName(bank.getBankName());
			bde.setCustomer(cd);
			
			session.save(bde);
			return bank;
	
		
	}

	
	@Override
	public Integer balance(String accountNumber, String bankName,String Pin) {
		Session session=sessionFactory.getCurrentSession();
		BankDetailEntity cde=session.get(BankDetailEntity.class,accountNumber);
	
		String account=accountNumber.toString();
		
	if(cde.getPin().toString().equals(Pin)){
	System.out.println("inside pin");
	if(bankName.equals("SBI")){
		System.out.println("inside sbi");
	CriteriaBuilder builder=session.getCriteriaBuilder();
	CriteriaQuery<SBIEntity> sbi=builder.createQuery(SBIEntity.class);
	Root<SBIEntity> root1=sbi.from(SBIEntity.class);
	sbi.select(root1);
	sbi.where(builder.like(root1.get("accountNumber"),account));
	List<SBIEntity> sb = session.createQuery(sbi).list();
	
	return sb.get(0).getBalance();	}
	if(bankName.equals("SBI")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<SBIEntity> sbi=builder.createQuery(SBIEntity.class);
		Root<SBIEntity> root1=sbi.from(SBIEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<SBIEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
	
	if(bankName.equals("ICICI")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<ICICIEntity> sbi=builder.createQuery(ICICIEntity.class);
		Root<ICICIEntity> root1=sbi.from(ICICIEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<ICICIEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
	
	if(bankName.equals("AXIS")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<AXISEntity> sbi=builder.createQuery(AXISEntity.class);
		Root<AXISEntity> root1=sbi.from(AXISEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<AXISEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
	
	if(bankName.equals("KVB")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<KVBEntity> sbi=builder.createQuery(KVBEntity.class);
		Root<KVBEntity> root1=sbi.from(KVBEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<KVBEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
	
	if(bankName.equals("HDFC")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<HDFCEntity> sbi=builder.createQuery(HDFCEntity.class);
		Root<HDFCEntity> root1=sbi.from(HDFCEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<HDFCEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
	if(bankName.equals("BOI")){
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<BOIEntity> sbi=builder.createQuery(BOIEntity.class);
		Root<BOIEntity> root1=sbi.from(BOIEntity.class);
		sbi.select(root1);
		sbi.where(builder.like(root1.get("accountNumber"),account));
		List<BOIEntity> sb = session.createQuery(sbi).list();
		
		return sb.get(0).getBalance();	}
		
	}
	return null;
}
	





}
