package com.infy.service;

import com.infy.model.CustomerDetail;
import com.infy.model.sessiontrack;

public interface CustomerService {
	public CustomerDetail getdetails(Integer customerid) throws Exception;

	public CustomerDetail updatePhoneNumber(CustomerDetail bank) throws Exception;
	
	public CustomerDetail add(CustomerDetail cust) throws Exception;
	
	public CustomerDetail login(String phoneno,String password) throws Exception;
	
	public sessiontrack session(sessiontrack ses) throws Exception;
	
	public String logout() throws Exception;
}
