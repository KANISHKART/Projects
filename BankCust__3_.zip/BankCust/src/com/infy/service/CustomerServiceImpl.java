package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.BankDAO;
import com.infy.dao.CustomerDAO;
import com.infy.model.CustomerDetail;
import com.infy.model.sessiontrack;

@Service("CustomerService")
@Transactional(readOnly = true)
public class CustomerServiceImpl  implements CustomerService{
	
private static int id;
public static int getId() {
	return id;
}
public static void setId(int id) {
	CustomerServiceImpl.id = id;
}
@Autowired
private CustomerDAO custdao;

	@Transactional(readOnly = true)
	public CustomerDetail getdetails(Integer customerid) throws Exception {
		CustomerDetail bs = custdao.getdetails(customerid);
		
		if(bs==null) {
		
			throw new Exception("Service.INVALID");
		}
		
		return bs;
	}
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public CustomerDetail updatePhoneNumber(CustomerDetail bank) throws Exception {
		CustomerDetail bankca = custdao.updatePhoneNumber(bank);
		if(bankca == null){
			throw new Exception("Service.INVALID");
		}
		
		return bankca;
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)

	public CustomerDetail add(CustomerDetail cust) throws Exception {
		// TODO Auto-generated method stub
		cust.setCustomerid(id);
		id+=1;
		CustomerDetail cd=custdao.add(cust);
	
		if(cd==null){
			throw new Exception("Service.INVALID");
		}
		return cd;
	}

	@Override
	@Transactional(readOnly = true)

	public CustomerDetail login(String phoneno, String password) throws Exception {
		// TODO Auto-generated method stub
	
		CustomerDetail bs = custdao.login(phoneno,password);
		
		if(bs==null) {
			
			throw new Exception("Service.INVALID_LOGIN");
		}
		
		return bs;
	}

	@Override
	@Transactional(readOnly = true)

	public sessiontrack session(sessiontrack ses) throws Exception {
		// TODO Auto-generated method stub
		
		sessiontrack sc=custdao.session(ses);
		System.out.println(sc.getSessionid());
		System.out.println(sc.getCustomerid());
		return sc;

	}
	@Override
	public String logout() throws Exception {
		// TODO Auto-generated method stub
		String s=custdao.logout();
		System.out.println(s);
		return s;
	}
	
	
}
