package com.infy.service;

import java.util.Dictionary;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.BankDAO;
import com.infy.dao.CustomerDAO;
import com.infy.entity.BankDetailEntity;
import com.infy.model.BankDetail;
import com.infy.model.CustomerDetail;



@Service("BankService")
@Transactional(readOnly = true)
public class BankServiceImpl implements BankService {

	
	@Autowired
	private BankDAO dao;
	@Autowired
	private CustomerDAO custdao;
	
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public BankDetail addetails(BankDetail bank)throws Exception {
		System.out.println("in service");
		BankDetail add = dao.addetails(bank);
		if(add == null){
			throw new Exception("BankApi.INVALID");
		}
		
	System.out.println("-------------------");

		System.out.println(add.getAccountNumber());
		System.out.println(add.getIfsc());
		System.out.println(add.getName());
		System.out.println(add.getPhoneNumber());
		System.out.println(add.getCustomer().getCustomerid());

		System.out.println("-------------------");
		return null;
		
	}

	@Override
	public Integer balance(String accountNumber,String bankName,String pin)throws Exception {
		// TODO Auto-generated method stub
		System.out.println("inside service");
		Integer bd=dao.balance(accountNumber,bankName,pin);
		System.out.println(bd);
		return bd;
}

	@Override
	public List transfer(BankDetail bank) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("in service transfer");
		List updatedBalance=dao.transfer(bank);
		return updatedBalance;
	}

	@Override
	public String transferMoney(BankDetail bank, List l, List list,String pin) throws Exception {
		// TODO Auto-generated method stub
		
		String success=dao.transferMoney(bank,l,list,pin);
		if(success.equals("pin_error")){
			throw new Exception("BankApi.INVALID_PIN");
		}
		return success;
	}

	@Override
	public Dictionary compare(BankDetail bank,int amount, int year) {
		// TODO Auto-generated method stub
		Dictionary gee=dao.compare(bank,amount,year);
		return gee;
	}






	
	

	

	
}


