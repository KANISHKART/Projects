package com.infy.service;

import java.util.Dictionary;
import java.util.List;

import com.infy.model.BankDetail;
import com.infy.model.CustomerDetail;

public interface BankService {

	
	public BankDetail addetails(BankDetail bank) throws Exception;

	public Integer balance(String accountNumber, String bankName,String pin)throws Exception;
	
	public List transfer(BankDetail bank) throws Exception;
	
	public String transferMoney(BankDetail bank,List l,List list,String pin)throws Exception;

	public Dictionary compare(BankDetail bank, int amount, int year);

}
