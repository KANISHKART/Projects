drop table BankDetail;
create table BankDetail (
accountNumber number(16) not null PRIMARY KEY,
name varchar2(30) not null,
ifsc varchar2(50) not null,
phoneNumber number(10) not null,
bankName varchar2(35) not null,
pin number(6) not null,
custid number(5) not null references CustomerDetail(customerid) 
);
CREATE SEQUENCE hibernate_sequence START WITH 2011 INCREMENT BY 1;
create table CustomerDetail(
customerid number(5) not null PRIMARY KEY,
firstname varchar2(30) not null,
middlename varchar2(30) not null,
lastname varchar2(30) not null,
dob date not null,
password varchar2(30) not null,
repassword varchar2(30) not null,
emailid varchar2(50) not null,
phoneno number(10) not null 
);


create table interest(
bankName varchar2(35) not null PRIMARY KEY,
interest numeric(6,2) not null);

insert into interest values('SBI',8.4);
insert into interest values('ICICI',7.4);
insert into interest values('AXIS',9.2);
insert into interest values('HDFC',6.7);
insert into interest values('KVB',7.2);
insert into interest values('BOI',9.4);
     
select * from CustomerDetail;

select * from ICICI;

create table transaction(
transactionid number(12) not null PRIMARY KEY,
tobank varchar2(25) not null,
frombank varchar2(25) not null,
money number(15) not null
);



select * from transaction;
drop table transaction;
create table ICICI(
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

create table SBI(
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

create table AXIS (
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

create table HDFC (
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

create table  KVB(
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

create table BOI(
accountNumber number(16) PRIMARY KEY,
name varchar2(30) not null,
dateOfBirth date not null,
ifsc varchar2(50) not null,
balance number(10) not null,
phoneNumber number(10) not null
);

Select * from BankDetail;
Select * from SBI;
Select * from ICICI;

insert into SBI values(1234567812345678, 'Nidhi', '12-Jan-1993', 'mys12345',50000,1234567890);
insert into SBI values(1234567812345671, 'viswa', '18-May-1997', 'cbe12345',50000,1234567899);
insert into SBI values(1234567812345672, 'kpa', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into SBI values(1234567812345673, 'ramesh', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into SBI values(1234567812345674, 'bheem', '12-Jan-1993', 'mys12345',50000,1234567811);



insert into ICICI values(2234567812345678, 'sudheer', '12-Jan-1993', 'mys12345',50000,1234567890);
insert into ICICI values(2234567812345671, 'viswa', '18-May-1997', 'cbe12345',50000,1234567899);
insert into ICICI values(2234567812345672, 'kpa', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into ICICI values(2234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into ICICI values(2234567812345674, 'bheem', '12-Jan-1993', 'mys12345',50000,1234567811);

insert into KVB values(3234567812345678, 'nidhi', '12-Jan-1993', 'mys12345',50000,1234567890);
insert into KVB values(3234567812345671, 'viswa', '18-May-1997', 'cbe12345',50000,1234567899);
insert into KVB values(3234567812345672, 'Shekhar', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into KVB values(3234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into KVB values(3234567812345674, 'bheem', '12-Jan-1993', 'mys12345',50000,1234567811);


insert into AXIS values(4234567812345678, 'nidhi', '12-Jan-1993', 'mys12345',50000,1234567890);
insert into AXIS values(4234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into AXIS values(4234567812345672, 'Shekhar', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into AXIS values(4234567812345671, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into AXIS values(4234567812345674, 'bheem', '12-Jan-1993', 'mys12345',50000,1234567811);


insert into HDFC values(5234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);
insert into HDFC values(5234567812345672, 'kpa', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into HDFC values(5234567812345671, 'viswa', '18-May-1997', 'cbe12345',50000,1234567899);
insert into HDFC values(5234567812345674, 'Shekhar', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into HDFC values(5234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);

insert into BOI values(6234567812345674, 'bheem', '12-Jan-1993', 'mys12345',50000,1234567811);
insert into BOI values(6234567812345672, 'kpa', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into BOI values(6234567812345671, 'viswa', '18-May-1997', 'cbe12345',50000,1234567899);
insert into BOI values(6234567812345675, 'Shekhar', '12-feb-1993', 'hyd12345',50000,1234567892);
insert into BOI values(6234567812345673, 'rajan', '12-Jan-1993', 'ngl1234',50000,1234567800);


select * from HDFC;

