package com.infy.entity;





import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.infy.model.CustomerDetail;


@Entity
@Table(name ="BankDetail")
public class BankDetailEntity {
	
	@Id
	private String accountNumber;
	private String name;
	private String ifsc;
	private String phoneNumber;
	private String bankName;
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Integer getPin() {
		return pin;
	}
	public void setPin(Integer pin) {
		this.pin = pin;
	}
	private Integer pin;
	@ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="custid")
    private CustomerDetailEntity customer;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public CustomerDetailEntity getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerDetailEntity customer) {
		this.customer = customer;
	}
	


	



}
