package com.infy.api;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dao.CustomerDAOImpl;
import com.infy.model.CustomerDetail;
import com.infy.model.sessiontrack;
import com.infy.service.BankService;
import com.infy.service.BankServiceImpl;
import com.infy.service.CustomerService;
import com.infy.service.CustomerServiceImpl;
import com.infy.utility.ContextFactory;

@RestController
@CrossOrigin
@RequestMapping(value="CustomerApi")
public class CustomerApi {
	private CustomerService service;
	
	private static Integer id;
	public static Integer getId() {
		return id;
	}


	public static void setId(Integer id) {
		CustomerApi.id = id;
	}


	@RequestMapping(method=RequestMethod.POST, value="getdetails")
	public ResponseEntity<CustomerDetail> getdetails(@RequestBody CustomerDetail bank){
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		
		ResponseEntity<CustomerDetail> responseEntity;
		try{
			CustomerDetail bs=service.getdetails(bank.getCustomerid());
			
			responseEntity = new ResponseEntity<CustomerDetail>(bs,HttpStatus.OK);
		}catch(Exception e){
			String errorMessage = environment.getProperty(e.getMessage());
			CustomerDetail fb = new CustomerDetail();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<CustomerDetail>(fb,HttpStatus.BAD_REQUEST);

		}
		return responseEntity;
		
	}
	
	 
	@RequestMapping(method=RequestMethod.POST, value="login")
	public ResponseEntity<CustomerDetail> login(@RequestBody CustomerDetail bank){
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		
		ResponseEntity<CustomerDetail> responseEntity;
		try{
			System.out.println("in try");
			CustomerDetail bs=service.login(bank.getPhoneno(),bank.getPassword());
			
			this.id=bs.getCustomerid();
			
			bs.setMessage(environment.getProperty("CustomerApi.LOGIN"));
			responseEntity = new ResponseEntity<CustomerDetail>(bs,HttpStatus.OK);
		}catch(Exception e){
			String errorMessage = environment.getProperty(e.getMessage());
			CustomerDetail fb = new CustomerDetail();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<CustomerDetail>(fb,HttpStatus.BAD_REQUEST);

		}
		return responseEntity;
		
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="updatePhoneNumber")
	public ResponseEntity<CustomerDetail> updatePhoneNumber(@RequestBody CustomerDetail bank){

		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		
		ResponseEntity<CustomerDetail> responseEntity;
		try {
			CustomerDetail bd = service.updatePhoneNumber(bank);
			bd.setMessage(environment.getProperty("CustomerApi.SUCCESSFULL"));
			responseEntity = new ResponseEntity<CustomerDetail>(bd,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			CustomerDetail fb = new CustomerDetail();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<CustomerDetail>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

	}
	



@RequestMapping(method=RequestMethod.POST, value="add")
	public ResponseEntity<CustomerDetail> add(@RequestBody CustomerDetail cust){
		Environment environment= ContextFactory.getContext().getEnvironment();
		
		service = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		
		ResponseEntity<CustomerDetail> responseEntity;
		try {
		
			CustomerDetail cd = service.add(cust);
			cd.setMessage(environment.getProperty("CustomerApi.SUCCESS"));
			responseEntity = new ResponseEntity<CustomerDetail>(cd,HttpStatus.OK);

		}

		catch(Exception exception) {
			String errorMessage = environment.getProperty(exception.getMessage());
			CustomerDetail fb = new CustomerDetail();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<CustomerDetail>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;

			
		
}
@RequestMapping(method=RequestMethod.GET, value="logout")
public ResponseEntity<String> logout(){
	Environment environment= ContextFactory.getContext().getEnvironment();
	
	service = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
	
	ResponseEntity<String> responseEntity;
	try {
	
		String cd = service.logout();
		System.out.println(cd);
		responseEntity = new ResponseEntity<String>(cd,HttpStatus.OK);

	}

	catch(Exception exception) {
		String errorMessage = environment.getProperty(exception.getMessage());

		responseEntity = new ResponseEntity<String>(errorMessage,HttpStatus.BAD_REQUEST);

	}

	return responseEntity;

		
	
}


}
