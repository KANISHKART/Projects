package com.infy.api;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import javax.swing.plaf.synth.SynthSeparatorUI;

import org.springframework.core.env.Environment;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.dao.CustomerDAOImpl;
import com.infy.model.BankDetail;
import com.infy.model.CustomerDetail;
import com.infy.service.BankService;
import com.infy.service.BankServiceImpl;
import com.infy.service.CustomerService;
import com.infy.service.CustomerServiceImpl;
import com.infy.utility.ContextFactory;


@RestController
@CrossOrigin
@RequestMapping(value="BankApi")
public class BankApi {
	private BankService service;
	private CustomerService service1;
	

	@RequestMapping(method=RequestMethod.POST, value="addetails")
	public ResponseEntity<BankDetail> adddetails(@RequestBody BankDetail bank){
		Environment environment= ContextFactory.getContext().getEnvironment();
			
		service = (BankService) ContextFactory.getContext().getBean(BankServiceImpl.class);
		service1 = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);

		ResponseEntity<BankDetail> responseEntity;
		try {
			CustomerDetail cd=service1.getdetails(CustomerApi.getId());
			bank.setCustomer(cd); 
			
			BankDetail bd = service.addetails(bank);
			
			responseEntity = new ResponseEntity<BankDetail>(bd,HttpStatus.OK);
		}

		catch(Exception exception) {
		
			String errorMessage = environment.getProperty(exception.getMessage());
			BankDetail fb = new BankDetail();
			fb.setMessage(errorMessage);
			responseEntity = new ResponseEntity<BankDetail>(fb,HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}
	@RequestMapping(method=RequestMethod.POST, value="balance")
	public ResponseEntity<Integer> balance(@RequestBody List<String> balance){
		Environment environment= ContextFactory.getContext().getEnvironment();
	
		service = (BankService) ContextFactory.getContext().getBean(BankServiceImpl.class);
		ResponseEntity<Integer> responseEntity;
		try {
			System.out.println(balance.get(0));
			System.out.println(balance.get(1));
			System.out.println(balance.get(2));
			
			
			Integer bd = service.balance(balance.get(0),balance.get(1),balance.get(2));
			
			responseEntity = new ResponseEntity<Integer>(bd,HttpStatus.OK);
		}

		catch(Exception exception) {
		
			responseEntity = new ResponseEntity<Integer>(HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.POST,value="compare")
	public ResponseEntity<Dictionary> compare(@RequestBody List<Integer> comp){
		Environment environment= ContextFactory.getContext().getEnvironment();
			
		service = (BankService) ContextFactory.getContext().getBean(BankServiceImpl.class);
		service1 = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		ResponseEntity<Dictionary> responseEntity;
		BankDetail bank=new BankDetail();
		try {
			
			CustomerDetail cd=service1.getdetails(CustomerApi.getId());
			bank.setCustomer(cd);
			
			Dictionary d = service.compare(bank,comp.get(0),comp.get(1));
			
			responseEntity = new ResponseEntity<Dictionary>(d,HttpStatus.OK);
		}

		catch(Exception exception) {
		
			responseEntity = new ResponseEntity<Dictionary>(HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}
	
	
	
	
	@RequestMapping(method=RequestMethod.GET,value="transfer")
	public ResponseEntity<List> transfer(){
		Environment environment= ContextFactory.getContext().getEnvironment();
			
		service = (BankService) ContextFactory.getContext().getBean(BankServiceImpl.class);
		service1 = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		ResponseEntity<List> responseEntity;
		BankDetail bank=new BankDetail();
		try {
			
			CustomerDetail cd=service1.getdetails(CustomerApi.getId());
			
			bank.setCustomer(cd);
			List bd = service.transfer(bank);
			
			responseEntity = new ResponseEntity<List>(bd,HttpStatus.OK);
		}

		catch(Exception exception) {
		
			responseEntity = new ResponseEntity<List>(HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="transferMoney")
	public ResponseEntity<String> transferMoney(@RequestBody List<Integer> l){
		Environment environment= ContextFactory.getContext().getEnvironment();
			
		service = (BankService) ContextFactory.getContext().getBean(BankServiceImpl.class);
		service1 = (CustomerService) ContextFactory.getContext().getBean(CustomerServiceImpl.class);
		ResponseEntity<String> responseEntity;
		BankDetail bank=new BankDetail();
		
		
		

		try {
			CustomerDetail cd=service1.getdetails(CustomerApi.getId());
			bank.setCustomer(cd);
			List bd = service.transfer(bank);
			System.out.println("heelo"+bank.getCustomer().getCustomerid());
			String pin=l.get(l.size()-1).toString();
			System.out.println(pin);
			String b = service.transferMoney(bank,bd,l,pin);
			
			
			responseEntity = new ResponseEntity<String>(b,HttpStatus.OK);
		}

		catch(Exception exception) {
		
			responseEntity = new ResponseEntity<String>(HttpStatus.BAD_REQUEST);

		}

		return responseEntity;
	}
	
	}


